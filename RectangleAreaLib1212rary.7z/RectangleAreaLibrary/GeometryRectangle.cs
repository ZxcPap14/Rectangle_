﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RectangleAreaLibrary
{
    public class GeometryRectangle
    {
        /// <summary>
        /// Вычисление площади прямоугольника по двум сторонам
        /// </summary>
        /// <param name="width"></param>
        /// Ширина прямоугольника 
        /// <param name="height"></param>
        /// <returns>
        /// Площадь прямоугольника
        /// </returns>
        public double RectangleArea(string width, string height)
        {
            double numbers;
            width = width.Replace('.', ',');
            height = height.Replace(".", ",");
            bool result = double.TryParse(width, out numbers);
            bool res = double.TryParse(height, out numbers);

            if (!result || !res)
            {
                throw new Exception("Введите недопустимые символы");
            }
            if (width == string.Empty || height == string.Empty)
            {
                throw new Exception("Не введена сторона прямоугольника");
            }
            if (Convert.ToDouble(width) <= 0 || Convert.ToDouble(height) <= 0)
            {
                throw new Exception("Длины сторон должны иметь положительные значения");
            }
            return Convert.ToDouble(width) * Convert.ToDouble(height);
            
        }
       
    }
}
